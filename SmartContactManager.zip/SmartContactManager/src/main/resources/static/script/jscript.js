/**
 * 
 */
 const togglesidebar=()=>{
if($(".sidebar").is(":visible")){

    $(".sidebar").css("display","none");
    $(".sidebar").css("margin-left","0%")
}

else{

    $(".sidebar").css("display","block");
    $(".sidebar").css("margin-left","20%")

 }


 }
 