package com.smart.handler;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.smart.dao.Repository;
import com.smart.entity.User;
import com.smart.helper.Message;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;


@Controller
public class MyController {
	@Autowired
	private BCryptPasswordEncoder PasswordEncoder;
	
	@Autowired
	private Repository repository;
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("title", "Javed");
		return "home";
	}
	
	@RequestMapping(value = "/signup",method = RequestMethod.GET)
	public String signup(Model model) {
		
		model.addAttribute("user",new User());
		return "signup";
	}
	
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("user") User user,BindingResult result,@RequestParam(value = "agreement",defaultValue = "false") boolean agreement, Model model, HttpSession session) {
		
		try {
			if(!agreement) {
				
				System.out.println("please check...");
				throw new Exception("forget to accept terms and condtion....");	
			}
			
			if(result.hasErrors()) {
				
				model.addAttribute("user", user);
				return "signup";
			}
			user.setEnabled(true);
			user.setRole("ROLE_USER");
			user.setImageUrl("img.png");
			user.setPassword(PasswordEncoder.encode(user.getPassword()));
			model.addAttribute("user", new User());
			session.setAttribute("message", new Message("Successfully registered ...","alert-success"));
			repository.save(user);
		}
		catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			model.addAttribute("user",user);
			session.setAttribute("message", new Message("Something went wrong! ..."+e.getMessage(),"alert-danger"));
			
		}	
		return "signup";
	}
	
	@GetMapping("/signin")
	public String log() {
		
		return "login";
	}
}
