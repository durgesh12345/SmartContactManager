package com.smart.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.smart.dao.Repository;
import com.smart.entity.User;

public class CustomizedUserDetailService implements UserDetailsService {
	
    @Autowired
	Repository repository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	
	   User	user=repository.getUserByUserName(username);
	   if(user==null) {
		   throw new UsernameNotFoundException("user not found...");
	   }
	   
	   CustomizedUserDetails cud=new CustomizedUserDetails(user);
	   return cud;
	}

}
